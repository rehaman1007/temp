# Glassmorphism Vite React Demo

What you get:
- Vite + React project using MUI and Framer Motion.
- Glassmorphism / liquid glass visual theme.
- Login page with legal warning + announcements panel.
- Layout with Sidebar, Topbar (notifications/profile), Breadcrumbs, Footer, Home page and dummy pages.

How to run:
1. unzip and open this folder
2. run `npm install`
3. run `npm run dev`
4. open http://localhost:5173 and go to /login

Notes:
- This is a UI demo scaffold intended for quick testing and iteration.
- Tweak components and styles under `src/` to add your own interactions.
