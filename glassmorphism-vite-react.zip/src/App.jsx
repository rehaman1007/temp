import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import Login from './pages/Login'
import Layout from './components/Layout'
import Home from './pages/Home'
import DummyPage from './pages/DummyPage'

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: '#7dd3fc' },
    background: { default: '#0f172a', paper: 'rgba(255,255,255,0.04)' }
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: { backdropFilter: 'blur(8px)', background: 'linear-gradient(135deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))' }
      }
    }
  }
})

export default function App(){
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline/>
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path="/" element={<Layout/>}>
          <Route index element={<Home/>}/>
          <Route path="page/:name" element={<DummyPage/>}/>
        </Route>
        <Route path="*" element={<Navigate to="/login" replace/>}/>
      </Routes>
    </ThemeProvider>
  )
}
