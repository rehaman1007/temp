import React from 'react'
import { motion } from 'framer-motion'
import { Typography } from '@mui/material'

const dummy = [
  {title:'Maintenance', body:'Scheduled maintenance on Sunday 02:00-04:00 IST.'},
  {title:'New feature', body:'Try the new glassy widgets on homepage.'}
]

export default function AnnouncementPanel(){
  return (
    <div style={{display:'flex',flexDirection:'column',gap:10}}>
      {dummy.map((a,i)=>(
        <motion.div key={i} initial={{opacity:0, x:-10}} animate={{opacity:1,x:0}} transition={{delay:0.08*i}} className="announce-item">
          <Typography variant="subtitle2">{a.title}</Typography>
          <Typography variant="body2" className="small-muted">{a.body}</Typography>
        </motion.div>
      ))}
    </div>
  )
}
