import React from 'react'
import { Outlet, Link, useNavigate } from 'react-router-dom'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import BreadcrumbsComp from './BreadcrumbsComp'
import Footer from './Footer'
import { Box } from '@mui/material'

export default function Layout(){
  return (
    <div style={{padding:20}}>
      <div style={{display:'flex', gap:20}}>
        <div className="sidebar glass">
          <Sidebar/>
        </div>

        <div style={{flex:1, display:'flex', flexDirection:'column', gap:12}}>
          <div className="topbar glass">
            <Topbar/>
          </div>
          <div className="breadcrumbs glass">
            <BreadcrumbsComp/>
          </div>

          <div className="main-content glass" style={{minHeight:420}}>
            <Outlet/>
          </div>

          <Footer/>
        </div>
      </div>
    </div>
  )
}
