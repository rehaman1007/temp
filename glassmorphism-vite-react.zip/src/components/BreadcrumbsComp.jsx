import React from 'react'
import { Breadcrumbs, Link, Typography } from '@mui/material'
import { useLocation } from 'react-router-dom'

export default function BreadcrumbsComp(){
  const loc = useLocation()
  const parts = loc.pathname.split('/').filter(Boolean)
  return (
    <Breadcrumbs aria-label="breadcrumb">
      <Link underline="hover" color="inherit" href="/">Home</Link>
      {parts.map((p,i)=> i === parts.length-1 ? <Typography key={i} color="text.primary">{p}</Typography> : <Link key={i} underline="hover" color="inherit" href={`/${parts.slice(0,i+1).join('/')}`}>{p}</Link>)}
    </Breadcrumbs>
  )
}
