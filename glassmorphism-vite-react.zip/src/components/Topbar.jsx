import React from 'react'
import { IconButton, Avatar, Badge } from '@mui/material'
import NotificationsIcon from '@mui/icons-material/Notifications'

export default function Topbar(){
  return (
    <>
      <div style={{display:'flex',alignItems:'center',gap:12}}>
        <h3 style={{margin:0}}>Dashboard</h3>
        <div className="small-muted" style={{marginLeft:8}}>Overview & interactive widgets</div>
      </div>

      <div style={{display:'flex',alignItems:'center',gap:8}}>
        <IconButton><Badge badgeContent={3} color="primary"><NotificationsIcon/></Badge></IconButton>
        <Avatar>U</Avatar>
      </div>
    </>
  )
}
