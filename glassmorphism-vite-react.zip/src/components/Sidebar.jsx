import React from 'react'
import { List, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material'
import DashboardIcon from '@mui/icons-material/Dashboard'
import PagesIcon from '@mui/icons-material/MenuBook'
import SettingsIcon from '@mui/icons-material/Settings'
import { Link } from 'react-router-dom'

export default function Sidebar(){
  return (
    <div>
      <div style={{display:'flex',alignItems:'center',gap:12, marginBottom:18}}>
        <div style={{width:44,height:44,borderRadius:10, background:'linear-gradient(135deg,#7dd3fc,#8b5cf6)'}} />
        <div>
          <Typography variant="subtitle1">Tranche</Typography>
          <div className="small-muted">Demo account</div>
        </div>
      </div>

      <List>
        <ListItemButton component={Link} to="/">
          <ListItemIcon><DashboardIcon/></ListItemIcon>
          <ListItemText primary="Home"/>
        </ListItemButton>

        <ListItemButton component={Link} to="/page/reports">
          <ListItemIcon><PagesIcon/></ListItemIcon>
          <ListItemText primary="Reports"/>
        </ListItemButton>

        <ListItemButton component={Link} to="/page/settings">
          <ListItemIcon><SettingsIcon/></ListItemIcon>
          <ListItemText primary="Settings"/>
        </ListItemButton>
      </List>
    </div>
  )
}
