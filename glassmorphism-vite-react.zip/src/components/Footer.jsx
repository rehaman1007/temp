import React from 'react'

export default function Footer(){
  return <div className="footer glass">© {new Date().getFullYear()} Tranche UI — All rights reserved.</div>
}
