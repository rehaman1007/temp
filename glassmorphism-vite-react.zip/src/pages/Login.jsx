import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Box, TextField, Button, Typography, Divider } from '@mui/material'
import AnnouncementPanel from '../components/AnnouncementPanel'

export default function Login(){
  const [agree, setAgree] = useState(false)
  const navigate = useNavigate()

  function handleLogin(e){
    e.preventDefault()
    if(!agree){ alert('Please accept legal warning'); return }
    navigate('/')
  }

  return (
    <div className="login-root">
      <motion.div initial={{opacity:0, y:20}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="glass login-panel">
        <div className="left-hero">
          <div style={{display:'flex',alignItems:'center',gap:12}}>
            <div className="logo" />
            <div>
              <Typography variant="h5">Tranche UI</Typography>
              <div className="small-muted">Interactive web app — glassmorphism theme</div>
            </div>
          </div>

          <Divider sx={{my:2}}/>

          <Typography variant="body2" className="small-muted">Welcome! This demo implements a liquid glass theme inspired by iOS concepts. Use the panel to login quickly.</Typography>

          <Box sx={{mt:2}}>
            <AnnouncementPanel/>
          </Box>

          <Box sx={{mt:'auto'}} className="small-muted">Demo only — no real authentication. Created for testing.</Box>
        </div>

        <div className="login-form">
          <Typography variant="h6">Sign in</Typography>
          <TextField label="Email" variant="filled" fullWidth />
          <TextField label="Password" variant="filled" type="password" fullWidth />
          <Box sx={{display:'flex', gap:12, alignItems:'center'}}>
            <label style={{display:'flex',gap:8,alignItems:'center'}}><input type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)} /> I accept legal warning</label>
            <div style={{flex:1}} />
            <Button variant="contained" onClick={handleLogin}>Login</Button>
          </Box>
          <Typography variant="caption" className="small-muted">Announcements are shown on the left.</Typography>
        </div>
      </motion.div>
    </div>
  )
}
