import React from 'react'
import { useParams } from 'react-router-dom'
import { Typography } from '@mui/material'

export default function DummyPage(){
  const { name } = useParams()
  return (
    <div>
      <Typography variant="h6">Page: {name}</Typography>
      <div className="small-muted">This is a dummy page for the sidebar route.</div>
    </div>
  )
}
