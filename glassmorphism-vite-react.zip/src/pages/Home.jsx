import React from 'react'
import { motion } from 'framer-motion'
import { Grid, Paper, Typography } from '@mui/material'

export default function Home(){
  return (
    <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{duration:0.6}}>
      <Typography variant="h5" gutterBottom>Welcome to the Glassmorphism Dashboard</Typography>

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={4}>
          <Paper className="glass" elevation={2} style={{padding:16}}>
            <Typography variant="subtitle1">Interactive Widget</Typography>
            <div style={{height:120, display:'flex',alignItems:'center',justifyContent:'center'}}>Liquid glass chart placeholder</div>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper className="glass" elevation={2} style={{padding:16}}>
            <Typography variant="subtitle1">Activity</Typography>
            <div style={{height:120}}>Recent events and animations</div>
          </Paper>
        </Grid>
      </Grid>
    </motion.div>
  )
}
